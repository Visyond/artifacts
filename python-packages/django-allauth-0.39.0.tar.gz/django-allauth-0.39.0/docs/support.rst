.. include:: ../README.rst
    :start-after: with flows that just work.
